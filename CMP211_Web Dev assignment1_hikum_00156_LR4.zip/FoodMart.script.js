function calculateTotal() {
  const checkboxes = document.querySelectorAll('input[name="item"]:checked');
  const selectedCount = checkboxes.length;

  if (selectedCount < 1 || selectedCount > 12) {
    alert("Please select your desired beverages for calculation.");
    return;
  }

  let total = 0;
  checkboxes.forEach((item) => {
    total += parseFloat(item.value);
  });

  alert(`Total amount for ${selectedCount} item(s): K${total.toFixed(2)}`);
}
